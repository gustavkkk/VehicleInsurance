#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  5 06:05:39 2017

@author: ubuntu
"""

"""
Created on Tue Sep 26 22:21:28 2017
@author: Frank
ref: https://stackoverflow.com/questions/10434599/how-to-get-data-received-in-flask-request
     https://www.reddit.com/r/flask/comments/5fl0xn/multifile_api_using_requests/
     https://github.com/mastercoder82/flask-test
     
     http://maximebf.com/blog/2012/10/building-websites-in-python-with-flask/#.WdcK0nVSw8o
     
     https://stackoverflow.com/questions/29221045/handling-urls-in-css-files-with-flask
     https://stackoverflow.com/questions/6978603/how-to-load-a-javascript-or-css-file-into-a-bottlepy-template
"""

import os
from flask import Flask, request, redirect, url_for,jsonify
from werkzeug import secure_filename
#import json
import time
import cv2
#from os.path import basename
from detect_lp import detect_by_seg_gf#,detect_by_gf

from feature.colorspace import opencv2skimage#,rgb2hsv,skimage2opencv
from feature.bbox import cropImg_by_BBox#,drawBBox,showResult
#from misc import pick_one_vehicle
from detect_vehicle import VehicleDetector
import html

#from os import listdir
from os.path import exists#,isfile, join
    
app = Flask(__name__)#, static_folder='static', static_url_path='')

UPLOAD_FOLDER = 'uploads'
WEBFILE_FOLDER = 'webfiles'
app.detector = VehicleDetector()
app.results = []
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['WEBFILE_FOLDER'] = WEBFILE_FOLDER
app.config['ALLOWED_EXTENSIONS'] = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])
app.config['MAX_CONTENT_LENGTH'] = 3 * 1024 * 1024    # 1 Mb limit
app.image_fn = os.path.join(app.config['UPLOAD_FOLDER'], "image.jpg")
app.result_fn = os.path.join(app.config['UPLOAD_FOLDER'], "result.txt")
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in app.config['ALLOWED_EXTENSIONS']

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    
    if request.method == 'POST':        
   
        file = request.files['file']
        

        if file and allowed_file(file.filename):
            # Delete tmp files
            if exists(app.image_fn):
                os.remove(app.image_fn)
            if exists(app.result_fn):
                os.remove(app.result_fn)
            app.results[:] = []
            # save an uploaded file to "uploads" folder
            #filename = secure_filename(file.filename)
            #file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(app.image_fn)
            #####################
            # Analyze the Image #
            #####################
            start=time.time()
            # Load Image
            image = cv2.imread(app.image_fn)  
            # Detect Vehicle           
            bbox_car = app.detector.detect(opencv2skimage(image))#mpimg.imread(path)
            img_car = cropImg_by_BBox(image,bbox_car)
            if bbox_car is not None:
                app.results.append("Vehicle : Yes ")
            # Detect License Plate
            bboxes_lp = detect_by_seg_gf(img_car)
            if bboxes_lp is not None:
                app.results.append("License Plate : Yes")
            end=time.time()
            elapsedtime = int((end-start)*1000)
            app.results.append("Elapsed time : " + str(elapsedtime) + "ms ")
            #######################
            #######################
            # Save Image and Result
            #os.rename(file_path, app.image_fn)
            with open(app.result_fn, 'w') as file:
                for result in app.results:
                    file.write(result)
                    file.write('\n')
                    
            return redirect("/")
            #return redirect(url_for('uploaded_file',
            #                        filename="facedetect-"+filename))

    results = ""
    for result in app.results:
        results += html.result_value_header + result + html.result_value_tail
    image = ""
    if exists(app.image_fn):
        image = html.image_header + html.image_fn + html.image_tail
    return  html.header + \
            html.result_header + \
            results + \
            html.result_tail +\
            html.image_container_header +\
            image + \
            html.image_container_tail + \
            html.tail
            
from flask import send_from_directory

@app.route('/uploads/<filename>')
def uploaded_file(filename):

    return send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)
    
from werkzeug import SharedDataMiddleware
app.add_url_rule('/uploads/<filename>', 'uploaded_file',
                 build_only=True)
app.wsgi_app = SharedDataMiddleware(app.wsgi_app, {
    '/uploads':  app.config['UPLOAD_FOLDER']
})
    
if __name__ == "__main__":
    app.run()#host= '0.0.0.0', debug=True, port=4000)